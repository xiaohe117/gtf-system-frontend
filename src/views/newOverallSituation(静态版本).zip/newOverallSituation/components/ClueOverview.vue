<template>
	<FrameBox class="module-frame clue-overview-frame">
		<section class="module clue-overview">
			<header class="module-header">
				<div class="header-left">
					<span class="double-arrow"></span>
					<span class="module-title">{{ clueData.title }}</span>
					<span class="target-text">{{ clueData.target.label }}</span>
					<strong>{{ clueData.target.value }}</strong>
					<span>{{ clueData.target.unit }}</span>
				</div>
				<button @click="clickParent('clubOverview')" class="enter-btn"><img :src="getImage(clueData.enterImage)" alt="" /></button>
			</header>

			<div class="clue-metrics">
				<div v-for="item in clueData.summary" :key="item.label" class="clue-metric">
					<div class="metric-label">{{ item.label }}</div>
					<div class="metric-value">
						<span>{{ item.value }}</span>
						<small>{{ item.unit }}</small>
					</div>
				</div>
			</div>

			<div class="clue-main">
				<div class="donut-wrap">
					<div class="donut-legend">
						<span v-for="(item, index) in clueData.pie.data" :key="item.name">
							<i :style="{ backgroundColor: pieLegendColors[index] }"></i>
							{{ item.name }}
						</span>
					</div>
					<div ref="chartRef" class="donut-chart"></div>
				</div>
				<div class="source-labels">
					<span>市内</span>
					<span>市外</span>
				</div>
				<div class="source-grid">
					<div
						v-for="(item, index) in clueData.sourceList"
						:key="item.name"
						class="source-item"
						:style="{
							backgroundImage: `url(${getImage(index < 2 ? 'beam-light.png' : 'beam-group.png')})`,
						}"
					>
						<div class="source-title">{{ item.name }}</div>
						<div>
							<strong>{{ item.count }}</strong>
							<span class="source-count-unit">个 共</span>
							<strong>{{ item.amount }}</strong>
							<span>亿元</span>
						</div>
					</div>
				</div>
			</div>
		</section>
	</FrameBox>
</template>

<script setup lang="ts">
import * as echarts from 'echarts';
import overallSituationData from '../data.json';
import useClickParent from '../composables/useClickParent';

const { clickParent } = useClickParent();

/** 线索总览 - 汇总指标项 */
interface ClueSummaryItem {
	/** 指标名称，如：线索数量、意向投资总额、任务完成率 */
	label: string;
	/** 指标值 */
	value: string;
	/** 单位，如：个、亿元 */
	unit: string;
}

/** 线索总览 - 项目来源项 */
interface ClueSourceItem {
	/** 项目名称，如：十亿元 + 项目、百亿元 + 项目 */
	name: string;
	/** 项目数量 */
	count: string;
	/** 投资金额（亿元） */
	amount: string;
}

/** 线索总览 - 饼图单项数据 */
interface CluePieDataItem {
	/** 来源名称，如：市内来源、市外来源、其他来源 */
	name: string;
	/** 占比文本，如：48.6% */
	value: string;
}

interface CluePieTooltipParam {
	marker?: string;
	name?: string;
	value?: number | string;
	data?: {
		percentText?: string;
	};
}

/** 线索总览 - 数据结构定义（对应 data.json 中的 clueOverview） */
interface ClueOverviewData {
	/** 模块标题：线索总览 */
	title: string;
	/** 进入按钮图片名称 */
	enterImage: string;
	/** 目标意向投资总额信息 */
	target: {
		/** 标签文本 */
		label: string;
		/** 投资额数值 */
		value: string;
		/** 单位 */
		unit: string;
	};
	/** 汇总指标列表（线索数量、意向投资总额、任务完成率） */
	summary: ClueSummaryItem[];
	/** 环形饼图数据 - 线索来源占比 */

	/** 项目来源列表（十亿元+、百亿元+ 项目等） */
	pie: {
		insidePercent: string;
		outsidePercent: string;
		data: CluePieDataItem[];
	};
	sourceList: ClueSourceItem[];
}

/** 从 data.json 中获取线索总览数据 */
const clueData = (overallSituationData as { clueOverview: ClueOverviewData }).clueOverview;
const pieLegendColors = ['#158dff', '#b9e8ff', '#bacce9'];

/** 根据 image 文件名拼接完整路径 */
const getImage = (name: string) => new URL(`../image/${name}`, import.meta.url).href;

/** ECharts 实例引用 */
const chartRef = ref<HTMLDivElement | null>(null);
let chartInstance: echarts.ECharts | null = null;

/**
 * 构建环形饼图配置项
 * @param data 饼图数据列表
 * @returns ECharts 配置项
 */
function buildPieOption(data: CluePieDataItem[]): echarts.EChartsOption {
	const pieData = data.map((item) => ({
		name: item.name,
		value: Number.parseFloat(item.value),
		percentText: item.value,
	}));

	return {
		tooltip: {
			trigger: 'item',
			position: 'right',
			extraCssText: `
				width: 2rem;
				height: 0.8rem;
				box-sizing: border-box;
				padding: 0.08rem 0.12rem;
			`,
			formatter: (params) => {
				const item = (Array.isArray(params) ? params[0] : params) as CluePieTooltipParam;
				const value = item.data?.percentText ?? `${item.value ?? ''}%`;

				return `<div style="height:100%;display:flex;align-items:center;justify-content:space-between;">
					<span style="display:inline-flex;align-items:center;min-width:0;">${item.marker ?? ''}${item.name ?? ''}</span>
					<span style="flex:0 0 auto;margin-left:20px;font-weight:700;">${value}</span>
				</div>`;
			},
		},
		color: pieLegendColors,
		legend: {
			show: false,
		},
		series: [
			{
				type: 'pie',
				radius: ['40%', '60%'],
				center: ['50%', '65%'],
				avoidLabelOverlap: false,
				label: {
					show: false,
					position: 'center',
				},
				labelLine: {
					show: false,
				},
				data: pieData,
			},
		],
	};
}

/** 初始化 ECharts 环形饼图 */
function initChart() {
	if (!chartRef.value) return;
	chartInstance = echarts.init(chartRef.value);
	chartInstance.setOption(buildPieOption(clueData.pie.data));
}

/** 窗口尺寸变化时重绘图表 */
function handleResize() {
	chartInstance?.resize();
}

onMounted(() => {
	initChart();
	window.addEventListener('resize', handleResize);
});

onBeforeUnmount(() => {
	window.removeEventListener('resize', handleResize);
	chartInstance?.dispose();
	chartInstance = null;
});
</script>

<style lang="less" scoped>
@import './moduleCommon.less';

.clue-overview-frame {
	min-height: 0;
	overflow: hidden;

	:deep(.outside-content) {
		min-height: 0;
		overflow: hidden;
		box-shadow: none;
	}

	:deep(.outside-content > div) {
		min-height: 0;
		overflow: hidden;
	}
}

.clue-overview {
	min-height: 0;
	overflow: hidden;
}

.clue-overview .module-header {
	grid-template-columns: minmax(1.79rem, auto) minmax(0, 1fr);
	column-gap: clamp(0.08rem, 0.9vw, 0.16rem);
}

.clue-metrics {
	position: relative;
	display: grid;
	grid-template-columns: 1fr 1.45fr 1fr;
	align-items: start;
	flex: 0 0 clamp(0.5rem, 6vh, 0.64rem);
	// margin-top: clamp(0.04rem, 1vh, 0.1rem);
	padding: clamp(0.07rem, 1.1vh, 0.12rem) clamp(0.16rem, 1.7vw, 0.32rem) 0;
	background: url('../image/section-line.png') center bottom / 100% 0.11rem no-repeat;
	overflow: hidden;

	// &::after {
	// 	position: absolute;
	// 	left: 68%;
	// 	top: 0.14rem;
	// 	width: 0.01rem;
	// 	height: 0.35rem;
	// 	content: '';
	// 	background: linear-gradient(180deg, rgba(79, 156, 255, 0), rgba(79, 156, 255, 0.55), rgba(79, 156, 255, 0));
	// }
}

.clue-metric {
	position: relative;
	z-index: 1;
	min-width: 0;
}

.clue-metric .metric-label {
	margin-bottom: 0.06rem;
	font-size: 0.15rem;
	line-height: clamp(0.15rem, 1.7vh, 0.18rem);
	font-family:
		PingFangSC,
		PingFang SC;
	color: #202a36;
	font-weight: 700;
}

.clue-metric .metric-value {
	display: flex;
	align-items: baseline;
	margin-top: 0;

	span {
		font-family: DINAlternate, DINAlternate;
		font-weight: bold;
		font-size: 0.24rem;
		color: #165dff;
		line-height: clamp(0.23rem, 2.6vh, 0.28rem);
		text-shadow: none;
	}

	small {
		margin-left: 0.04rem;
		font-family: PingFangHK, PingFangHK;
		font-weight: 400;
		font-size: 0.14rem;
		color: rgba(0, 0, 0, 0.65);
	}
}

.clue-main {
	--source-row-height: clamp(0.5rem, 5.6vh, 0.6rem);
	--source-row-gap: clamp(0.1rem, 1.8vh, 0.2rem);
	--source-top-offset: clamp(0.16rem, 2vh, 0.3rem);

	display: grid;
	grid-template-columns: minmax(0, 34%) clamp(0.32rem, 2.2vw, 0.42rem) minmax(0, 1fr);
	flex: 1 1 0;
	height: 0;
	min-height: 0;
	overflow: hidden;
	gap: 0;
	align-items: center;
	// padding: 0.06rem 0.03rem 0;
}

.donut-wrap {
	position: relative;
	height: min(100%, 1.22rem);
	max-height: 1.22rem;
	min-width: 0;
	overflow: visible;
}

.donut-legend {
	position: absolute;
	left: 0;
	top: 0;
	z-index: 2;
	display: flex;
	align-items: center;
	flex-wrap: nowrap;
	gap: clamp(0.04rem, 0.45vw, 0.02rem);
	width: max-content;
	white-space: nowrap;
	pointer-events: none;

	span {
		display: inline-flex;
		align-items: center;
		flex: 0 0 auto;
		color: #4f5966;
		font-size: clamp(0.1rem, 1.25vh, 0.12rem);
		font-weight: 700;
		line-height: 0.14rem;
	}

	i {
		flex: 0 0 auto;
		width: clamp(0.08rem, 0.7vw, 0.1rem);
		height: clamp(0.08rem, 0.7vw, 0.1rem);
		margin-right: 0.04rem;
		border-radius: 0.02rem;
	}
}

.donut-chart {
	width: 100%;
	height: 100%;
	min-height: 0;
}

.source-labels {
	display: grid;
	grid-template-rows: repeat(2, var(--source-row-height));
	align-content: center;
	justify-items: baseline;
	row-gap: var(--source-row-gap);
	height: calc(100% - var(--source-top-offset));
	min-width: 0;
	min-height: 0;
	margin-top: var(--source-top-offset);
	padding-right: 0.04rem;
	color: #fff;
	font-family:
		PingFangSC,
		PingFang SC,
		Microsoft YaHei,
		sans-serif;
	font-size: clamp(0.16rem, 1.9vh, 0.2rem);
	font-weight: 700;
	line-height: 1.05;
	text-align: center;
	white-space: nowrap;
	pointer-events: none;
}

.source-labels span {
	display: flex;
	align-items: center;
	justify-content: center;
	width: 50%;
	height: 80%;
	border-radius: 0.06rem 0 0 0.06rem;
	background: #1598ff;
	writing-mode: vertical-rl;
	text-orientation: upright;
	letter-spacing: 0;
	font-size: 0.14rem;
}

.source-labels span:nth-child(2) {
	background: #9fc4fb;
}

.donut-label {
	position: absolute;
	left: 0.9rem;
	z-index: 1;
	width: 0.52rem;
	font-size: 0.12rem;
	font-weight: 700;
	line-height: 1.08;
	color: #586777;
	white-space: pre-line;

	&::before {
		position: absolute;
		left: -0.42rem;
		width: 0.4rem;
		height: 0.01rem;
		content: '';
		background: #8cc2ff;
	}

	small {
		display: block;
		font-size: 0.1rem;
		color: #586777;
	}
}

.donut-label.inside {
	top: 0.2rem;

	&::before {
		top: 0.13rem;
		transform: rotate(-8deg);
		transform-origin: right center;
	}
}

.donut-label.outside {
	bottom: 0.16rem;

	&::before {
		top: 0.11rem;
		transform: rotate(18deg);
		transform-origin: right center;
	}
}

.source-grid {
	display: grid;
	grid-template-columns: repeat(2, minmax(0, 1fr));
	align-content: center;
	gap: var(--source-row-gap) 0.02rem;
	height: 100%;
	min-height: 0;
	margin-top: var(--source-top-offset);
	overflow-y: hidden;
	overflow-x: hidden;
}

.source-item {
	position: relative;
	min-width: 0;
	height: var(--source-row-height);
	padding: 0.02rem 0.02rem 0;
	background-position: center bottom;
	background-size: 100% 100%;
	background-repeat: no-repeat;

	&::before {
		position: absolute;
		left: 12%;
		top: 0%;
		width: 0.1rem;
		height: 0.1rem;
		content: '';
		background: url('@/views/newOverallSituation/image/dot-blue.png') no-repeat center / contain;
	}

	.source-title {
		margin-bottom: 0;
		margin-left: 0.06rem;
		font-family:
			PingFangSC,
			PingFang SC;
		font-weight: 400;
		font-size: 0.14rem;
		color: rgba(0, 0, 0, 0.65);
		line-height: clamp(0.15rem, 1.7vh, 0.18rem);
		text-align: center;
		z-index: 10;
		position: relative;
		top: -13%;
	}

	div:last-child {
		display: flex;
		align-items: center;
		justify-content: center;
		height: clamp(0.18rem, 2.1vh, 0.22rem);
		border-radius: 0.14rem;
		// background: linear-gradient(90deg, rgba(214, 235, 255, 0.92), rgba(244, 249, 255, 0.9));
		color: #67778a;
		position: relative;
		z-index: 0;
	}

	strong {
		margin: 0 0.04rem;
		font-size: 0.14rem;
		color: #333333;
	}

	span {
		font-size: 0.12rem;
	}

	.source-count-unit {
		flex: 0 0 auto;
		white-space: nowrap;
	}
}
</style>
