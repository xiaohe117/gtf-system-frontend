<template>
	<FrameBox class="module-frame scene-frame">
		<section class="module scene-overview">
			<header class="module-header">
				<div class="header-left">
					<span class="double-arrow"></span>
					<span class="module-title">{{ sceneData.title }}</span>
					<span class="target-text">{{ sceneData.target.label }}</span>
					<strong>{{ sceneData.target.value }}</strong>
					<span class="wcl"
						>个，完成率：<a>{{ sceneData.target.suffix }}</a></span
					>
				</div>
				<button @click="goScene()" class="enter-btn"><img :src="getImage(sceneData.enterImage)" alt="" /></button>
			</header>

			<div class="scene-metrics">
				<div v-for="item in sceneData.summary" :key="item.label">
					<span>{{ item.label }}</span>
					<p>
						<strong>{{ item.value }}</strong>
						<small>个</small>
					</p>
				</div>
			</div>
			<div class="scene-table">
				<el-table
					class="scene-el-table"
					:data="sceneData.rows"
					height="100%"
					row-key="name"
					scrollbar-always-on
				>
					<el-table-column
						v-for="column in sceneData.columns"
						:key="column.prop"
						:prop="column.prop"
						:label="column.label"
						:min-width="getColumnWidth(column.prop)"
						align="center"
						show-overflow-tooltip
					/>
				</el-table>
			</div>
		</section>
	</FrameBox>
</template>

<script setup lang="ts">
// import ServiceUrl from '@/utils/url';
import router from '@/router';
import overallSituationData from '../data.json';

/** 场景总览顶部目标信息 */
interface SceneTarget {
	/** 目标文案前缀 */
	label: string;
	/** 目标数量 */
	value: string;
	/** 目标数量后面的补充文案 */
	suffix: string;
}

/** 场景总览指标项 */
interface SceneSummaryItem {
	/** 指标名称 */
	label: string;
	/** 指标数值 */
	value: string;
	/** 趋势符号 */
	trend: string;
}

/** 场景总览表格列 */
interface SceneTableColumn {
	/** el-table-column 字段名 */
	prop: string;
	/** 表头文字，支持 \n 换行 */
	label: string;
	/** 列最小宽度，单位 px，用于触发横向滚动 */
	minWidth: number;
}

/** 场景总览表格行数据 */
interface SceneTableRow {
	name: string;
	open: string | number;
	ability: string | number;
	publish: string | number;
	project: string | number;
	invest: string | number;
}

/** 场景总览完整数据结构 */
interface SceneOverviewData {
	/** 模块标题 */
	title: string;
	/** 进入按钮图片文件名 */
	enterImage: string;
	/** 顶部目标信息 */
	target: SceneTarget;
	/** 三个指标卡数据 */
	summary: SceneSummaryItem[];
	/** 表格列配置 */
	columns: SceneTableColumn[];
	/** 表格行数据 */
	rows: SceneTableRow[];
}

const sceneData = (overallSituationData as { sceneOverview: SceneOverviewData }).sceneOverview;

const getImage = (name: string) => new URL(`../image/${name}`, import.meta.url).href;

const getColumnWidth = (prop: string) => {
	const columnWidths: Record<string, number> = {
		name: 110,
		open: 62,
		ability: 62,
		publish: 62,
		project: 62,
		invest: 76,
	};

	return columnWidths[prop] ?? 62;
};

const goScene = () => {
	// const url = router.resolve({ path: '/operationCenter/scene' });
	// window.open(url.href, '_blank');
	router.push({ path: '/operationCenter/scene' });
};
</script>

<style lang="less" scoped>
@import './moduleCommon.less';

.wcl {
	font-family:
		PingFangSC,
		PingFang SC;
	font-weight: 500;
	font-size: 0.17rem;
	line-height: 0.25rem;
	color: rgba(0, 0, 0, 0.7);
	a {
		font-family: DINAlternate, DINAlternate;
		font-weight: bold;
		font-size: 0.2rem;
		color: #165dff;
	}
}

.scene-frame {
	min-height: 0;
	overflow: hidden;

	:deep(.outside-content) {
		min-height: 0;
		overflow: hidden;
		box-shadow: none;
	}

	:deep(.outside-content > div) {
		min-height: 0;
		overflow: hidden;
	}
}

.scene-overview {
	min-height: 0;
	overflow: hidden;
}

.scene-metrics {
	display: grid;
	grid-template-columns: repeat(3, minmax(0, 1fr));
	flex: 0 0 clamp(0.55rem, 6.6vh, 0.7rem);
	align-items: start;
	padding: clamp(0.07rem, 1.1vh, 0.12rem) clamp(0.16rem, 1.8vw, 0.36rem) 0;
	background: url('../image/section-line.png') center bottom / 100% 0.11rem no-repeat;

	div {
		display: flex;
		flex-direction: column;
		align-items: center;
		font-weight: 700;
	}

	span {
		font-size: 0.15rem;
		line-height: clamp(0.15rem, 1.7vh, 0.18rem);
		color: #202a36;
		font-family:
			PingFangSC,
			PingFang SC;
	}

	p {
		display: flex;
		align-items: baseline;
		margin: 0.07rem 0 0;
	}

	strong {
		font-family: DINAlternate, DINAlternate;
		font-weight: bold;
		font-size: 0.24rem;
		color: #165dff;
		line-height: clamp(0.21rem, 2.3vh, 0.25rem);
	}

	small {
		margin-left: 0.15rem;
		line-height: clamp(0.17rem, 1.9vh, 0.2rem);
		font-weight: 400;
		font-size: 0.14rem;
		color: rgba(0, 0, 0, 0.65);
	}
}

.scene-table {
	flex: 1 1 0;
	height: 0;
	min-height: 0;
	overflow-x: auto;
	overflow-y: hidden;
	padding-top: 0.04rem;
}

.scene-el-table {
	width: 100%;
	height: 100%;
	min-width: 4.66rem;
	border: 0.01rem solid #b6d7ff;
	background: transparent;
	color: #4c5968;
	font-size: 0.13rem;
	font-weight: 700;

	:deep(.el-table__inner-wrapper::before),
	:deep(.el-table__inner-wrapper::after) {
		display: none;
	}

	:deep(.el-table__border-left-patch) {
		display: none;
	}

	:deep(.el-table__header-wrapper th.el-table__cell) {
		height: clamp(0.3rem, 3.4vh, 0.36rem);
		padding: 0;
		border-right: 0.01rem solid #bddcff;
		border-bottom: 0.01rem solid #bddcff;
		background: #e7f5ff;
		color: #3f4d5c;
		// font-size: 0.1rem;
		font-weight: 700;
	}

	:deep(.el-table__header-wrapper th.el-table__cell:last-child),
	:deep(.el-table__body-wrapper td.el-table__cell:last-child) {
		border-right: 0;
	}

	:deep(.el-table__cell .cell) {
		padding: 0 0.04rem;
		line-height: 0.17rem;
		white-space: pre-line;
	}

	:deep(.el-table__body-wrapper td.el-table__cell) {
		height: clamp(0.28rem, 3.1vh, 0.33rem);
		padding: 0;
		border-right: 0.01rem solid #bddcff;
		border-bottom: 0.01rem solid #bddcff;
		background: rgba(255, 255, 255, 0.9);
		color: #4b5665;
		font-size: 0.13rem;
		font-weight: 700;
	}

	:deep(.el-table__body tr:nth-child(even) td.el-table__cell) {
		background: #e5f2ff;
	}

	:deep(.el-table__body tr:hover > td.el-table__cell) {
		background: #e5f2ff;
	}

	:deep(.el-table__body-wrapper td.el-table__cell:first-child .cell) {
		padding-left: 0.08rem;
		white-space: nowrap;
		text-align: center;
	}

	:deep(.el-table__header),
	:deep(.el-table__body),
	:deep(.el-table__header-wrapper),
	:deep(.el-table__body-wrapper) {
		background: transparent;
	}
}
</style>
