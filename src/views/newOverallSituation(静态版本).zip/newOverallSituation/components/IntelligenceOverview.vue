<template>
	<FrameBox class="module-frame intelligence-frame">
		<section class="module intelligence-overview">
			<header class="module-header compact-header">
				<div
					class="tabs-item"
					:class="{ active: activeHeaderTab === 'intelligence' }"
					@click="activeHeaderTab = 'intelligence'"
				>
					<span class="module-title">招商情报</span>
					<div v-show="activeHeaderTab === 'intelligence'" class="title-bg"></div>
				</div>
				<div
					@click="goIndustryOverview"
					class="tabs-item tabs-item-industry"
					:class="{ active: activeHeaderTab === 'industry' }"
				>
					<span class="module-title">按产业分</span>
					<div v-show="activeHeaderTab === 'industry'" class="title-bg"></div>
				</div>
				<div class="go-btn">
					<img
						@click="clickParent('intelligenceOverview')"
						src="@/views/newOverallSituation/image/more.png"
						alt=""
					/>
				</div>
			</header>

			<div class="info-tabs">
				<span
					class="info-tabs-item"
					:class="{ active: activeInfoTab === 'meeting' }"
					@click="handleInfoTabClick('meeting')"
					>高层会见</span
				>
				<span
					class="info-tabs-item"
					:class="{ active: activeInfoTab === 'news' }"
					@click="handleInfoTabClick('news')"
					>企业资讯</span
				>
			</div>
			<div
				class="info-list"
				:class="{ 'meeting-info-list': activeInfoTab === 'meeting' }"
				v-loading="activeInfoTab === 'news' && isInfoLoading"
				element-loading-background="rgba(255, 255, 255, 0.72)"
				element-loading-text="加载中..."
			>
				<template v-if="activeInfoTab === 'meeting'">
					<div class="meeting-group">
						<div class="info-source-label">广东省</div>
						<div class="meeting-list">
							<div
								v-for="(item, index) in guangdongMeetingList"
								:key="item.id || `guangdong-${item.title}-${index}`"
								class="info-item"
							>
								<el-tooltip
									:content="item.tag"
									placement="top"
									:show-after="500"
									popper-class="my-tip"
								>
									<span class="info-tag">
										{{ truncateTag(item.tag) }}
									</span>
								</el-tooltip>
								<el-tooltip
									:content="item.title"
									placement="top"
									:show-after="500"
									popper-class="my-tip"
								>
									<p class="title-text">{{ item.title }}</p>
								</el-tooltip>
								<time class="date-text">{{ item.date }}</time>
							</div>
						</div>
					</div>

					<div class="meeting-group">
						<div class="info-source-label secondary">其他省市</div>
						<div class="meeting-list">
							<div
								v-for="(item, index) in otherProvinceMeetingList"
								:key="item.id || `other-${item.title}-${index}`"
								class="info-item"
							>
								<el-tooltip
									:content="item.tag"
									placement="top"
									:show-after="500"
									popper-class="my-tip"
								>
									<span class="info-tag" :title="item.tag">{{
										truncateTag(item.tag)
									}}</span>
								</el-tooltip>

								<el-tooltip
									:content="item.title"
									placement="top"
									:show-after="500"
									popper-class="my-tip"
								>
									<p class="title-text">{{ item.title }}</p>
								</el-tooltip>
								<time class="date-text">{{ item.date }}</time>
							</div>
						</div>
					</div>
				</template>

				<template v-else>
					<div v-if="!isInfoLoading && infoList.length === 0" class="info-empty">
						暂无数据
					</div>
					<div
						v-for="(item, index) in infoList"
						:key="item.id || `${item.title}-${index}`"
						class="info-item"
					>
						<span class="info-tag" :title="item.tag">{{ truncateTag(item.tag) }}</span>
						<el-tooltip
							:content="item.title"
							placement="top"
							:show-after="500"
							popper-class="my-tip"
						>
							<p class="title-text">{{ item.title }}</p>
						</el-tooltip>
					</div>
				</template>
			</div>
		</section>
	</FrameBox>
</template>

<script setup lang="ts">
import { useRouter } from 'vue-router';
import {
	getleadervisitGDList,
	getleadervisitNGDList,
	getsentimentdynamiclList,
} from '@/api/Intelligence/index';
import { onMounted, ref } from 'vue';
import useClickParent from '../composables/useClickParent';

const router = useRouter();

const { clickParent } = useClickParent();

const truncateTag = (tag: string) => {
	if (!tag) return '';
	return tag.length > 4 ? `${tag.slice(0, 4)}...` : tag;
};

type InfoTabKey = 'news' | 'meeting';

type InfoItem = {
	id?: number | string;
	tag: string;
	title: string;
	date: string;
};

type ApiListData<T> =
	| T[]
	| {
			records?: T[];
			rows?: T[];
			list?: T[];
	  };

type SentimentDynamicApiItem = {
	id?: number | string;
	pubTime?: string;
	title?: string;
};

type LeaderVisitApiItem = {
	id?: number | string;
	authorName?: string;
	title?: string;
	createdAt?: string;
};

const activeHeaderTab = ref('intelligence');
const activeInfoTab = ref<InfoTabKey>('meeting');
const infoList = ref<InfoItem[]>([]);
const guangdongMeetingList = ref<InfoItem[]>([]);
const otherProvinceMeetingList = ref<InfoItem[]>([]);
const isInfoLoading = ref(false);
let infoRequestId = 0;

const goIndustryOverview = () => {
	router.push({ path: '/commandCenter/classifiedByIndustry' });
};
// 接口列表可能直接返回数组，也可能包在 records/rows/list 中，这里统一抹平成数组。
function getApiList<T>(data: ApiListData<T> | null | undefined): T[] {
	if (Array.isArray(data)) return data;
	return data?.records || data?.rows || data?.list || [];
}

const formatDate = (value = '') => value.slice(0, 10);

const normalizeSentimentInfo = (item: any): InfoItem => ({
	id: item.id,
	tag: item.source || '-',
	title: item.title || '-',
	date: formatDate(item.pubTime),
});

const normalizeLeaderVisitGDInfo = (item: LeaderVisitApiItem): InfoItem => ({
	id: item.id,
	tag: item.authorName || '-',
	title: item.title || '-',
	date: formatDate(item.createdAt),
});

const normalizeLeaderVisitNGDInfo = (item: LeaderVisitApiItem): InfoItem => ({
	id: item.id,
	tag: item.authorName || '-',
	title: item.title || '-',
	date: formatDate(item.createdAt),
});

const getLeaderVisitGDInfoList = async () => {
	const res = await getleadervisitGDList<ApiListData<LeaderVisitApiItem>>();
	guangdongMeetingList.value =
		res.code === 0 ? getApiList(res.data).map(normalizeLeaderVisitGDInfo) : [];
};

const getLeaderVisitNGDInfoList = async () => {
	const res = await getleadervisitNGDList<ApiListData<LeaderVisitApiItem>>();
	otherProvinceMeetingList.value =
		res.code === 0 ? getApiList(res.data).map(normalizeLeaderVisitNGDInfo) : [];
};

// “企业资讯”tab 的加载函数：请求企业资讯接口，然后转成页面列表需要的字段。
const getSentimentInfoList = async () => {
	const res = await getsentimentdynamiclList<ApiListData<SentimentDynamicApiItem>>();
	return res.code === 0 ? getApiList(res.data).map(normalizeSentimentInfo) : [];
};

const getInfoList = async () => {
	// 每次请求前递增序号，用来识别“当前最新请求”。
	infoRequestId += 1;
	const requestId = infoRequestId;

	// 切换 tab 时先清掉旧列表并展示 loading，避免旧数据短暂残留。
	isInfoLoading.value = true;
	infoList.value = [];

	try {
		const list = await getSentimentInfoList();

		// 只有最新请求，并且用户还停留在“企业资讯”tab，才允许把接口结果写回页面。
		if (requestId === infoRequestId && activeInfoTab.value === 'news') {
			infoList.value = list;
		}
	} catch {
		// 接口异常时同样只处理“企业资讯”tab 的最新请求，避免覆盖用户切到的新 tab。
		if (requestId === infoRequestId && activeInfoTab.value === 'news') {
			infoList.value = [];
		}
	} finally {
		// loading 也只由最新请求关闭，防止旧请求提前关闭新请求的 loading。
		if (requestId === infoRequestId && activeInfoTab.value === 'news') {
			isInfoLoading.value = false;
		}
	}
};

const handleInfoTabClick = (tabKey: InfoTabKey) => {
	// 高层会见请求省内/省外两个列表；企业资讯保留原接口请求。
	activeInfoTab.value = tabKey;
	if (tabKey === 'news') {
		getInfoList();
	} else if (
		guangdongMeetingList.value.length === 0 ||
		otherProvinceMeetingList.value.length === 0
	) {
		getLeaderVisitGDInfoList();
		getLeaderVisitNGDInfoList();
	}
};

onMounted(() => {
	getLeaderVisitGDInfoList();
	getLeaderVisitNGDInfoList();
});
</script>

<style lang="less" scoped>
@import './moduleCommon.less';

.intelligence-frame {
	min-height: 0;
	overflow: hidden;

	:deep(.outside-content) {
		min-height: 0;
		overflow: hidden;
		box-shadow: none;
		padding: clamp(0.07rem, 0.9vh, 0.12rem) clamp(0.09rem, 0.9vw, 0.16rem)
			clamp(0.1rem, 1.2vh, 0.2rem) clamp(0.12rem, 1.2vw, 0.2rem);
	}

	:deep(.outside-content > div) {
		min-height: 0;
		overflow: hidden;
	}

	.intelligence-overview {
		min-height: 0;
		overflow: hidden;

		.compact-header {
			display: flex;
			align-items: center;
			gap: clamp(0.08rem, 0.8vw, 0.12rem);

			.tabs-item {
				position: relative;
				--info-title-tab-height: clamp(0.36rem, 4.4vh, 0.46rem);

				width: clamp(1.45rem, 9vw, 1.8rem);
				height: var(--info-title-tab-height);
				cursor: pointer;

				&.active {
					background: url('../image/step-base.png') left bottom / 100% 100% no-repeat;
				}

				.module-title {
					font-family: AlimamaShuHeiTi;
					font-weight: bold;
					font-size: clamp(0.2rem, 2.5vh, 0.24rem);
					line-height: var(--info-title-tab-height);
					text-align: left;
					padding-left: 0.24rem;
					margin-right: 0;
					color: rgba(78, 89, 105, 0.51);
					text-shadow: 2px 2px 0px #ffffff;
					background: unset;
				}

				&.active .module-title,
				&:hover .module-title {
					background: linear-gradient(90deg, #4f98ff 0%, #1936a9 100%);
					-webkit-background-clip: text;
					background-clip: text;
					color: transparent;
					text-shadow: none;
				}

				.title-bg {
					position: absolute;
					inset: 0;
					pointer-events: none;
				}
			}
			.tabs-item-industry {
				margin-left: -0.72rem;
			}
			.go-btn {
				width: clamp(0.82rem, 5.3vw, 1rem);
				height: clamp(0.2rem, 2.4vh, 0.26rem);
				cursor: pointer;
				img {
					width: 100%;
					height: 100%;
					object-fit: contain;
				}
			}
		}
	}
	.info-tabs {
		display: flex;
		align-items: center;
		gap: 0.12rem;
		flex-shrink: 0;
		margin: 0.02rem 0;
		.info-tabs-item {
			display: flex;
			align-items: center;
			justify-content: center;
			width: clamp(1.08rem, 7vw, 1.28rem);
			height: clamp(0.26rem, 3.2vh, 0.3rem);
			background-image: url('../image/pill-gray-mask.png');
			background-size: 100% 100%;
			background-position: center;
			font-family:
				PingFangSC,
				PingFang SC;
			font-weight: 600;
			font-size: 0.16rem;
			color: rgba(0, 0, 0, 0.65);
			cursor: pointer;
			&.active {
				color: #fff;
				background-image: url('../image/pill-blue-mask.png');
			}
		}
	}

	.info-list {
		position: relative;
		display: flex;
		flex-direction: column;
		gap: clamp(0.04rem, 1.3vh, 0.04rem);
		flex: 1 1 0;
		height: 0;
		min-height: 0;
		overflow-y: auto;
		overflow-x: hidden;

		&.meeting-info-list {
			overflow: hidden;
		}

		.info-empty {
			display: flex;
			align-items: center;
			justify-content: center;
			min-height: 1.2rem;
			font-size: 0.16rem;
			color: #8a919f;
		}
		.meeting-group {
			display: grid;
			grid-template-columns: 0.3rem minmax(0, 1fr);
			align-items: stretch;
			flex: 1 1 0;
			min-width: 0;
			min-height: 0;
		}
		.info-source-label {
			display: flex;
			align-items: center;
			justify-content: center;
			width: 0.3rem;
			min-height: 100%;
			border-radius: 0.07rem 0 0 0.07rem;
			background: #1598ff;
			color: #fff;
			font-family:
				PingFangSC,
				PingFang SC;
			font-size: clamp(0.13rem, 1.55vh, 0.16rem);
			font-weight: 700;
			line-height: 1.05;
			letter-spacing: 0;
			text-align: center;
			writing-mode: vertical-rl;
			text-orientation: upright;
			white-space: nowrap;
		}
		.info-source-label.secondary {
			background: #9fc4fb;
		}
		.meeting-list {
			display: flex;
			flex-direction: column;
			gap: 0.06rem;
			min-width: 0;
			min-height: 0;
			padding: 0.02rem 0;
			border: 0.01rem solid #168dff;
			border-left: 0;
			border-radius: 0 0.08rem 0.08rem 0;
			overflow-y: auto;
			overflow-x: hidden;
		}
		.info-item {
			display: flex;
			align-items: center;
			flex-shrink: 0;
			padding: 0.02rem 0.08rem;
			background: rgba(169, 181, 255, 0.1);
			border-radius: 1rem 0.18rem 0.18rem 1rem;
			.info-tag {
				display: flex;
				// align-items: center;
				justify-content: center;
				width: 0.76rem;
				height: 0.24rem;
				font-family:
					PingFangSC,
					PingFang SC;
				font-size: 0.12rem;
				color: #266fe8;
				padding-top: 0.02rem;
				border: 0.01rem solid #1982ff;
				border-radius: 0.12rem;
				flex-shrink: 0;
			}
			.title-text {
				flex: 1 1 auto;
				min-width: 0;
				font-family:
					PingFangSC,
					PingFang SC;
				font-size: 0.14rem;
				color: #4b4b4b;
				padding: 0 0.1rem 0 0.08rem;
				overflow: hidden;
				text-overflow: ellipsis;
				white-space: nowrap;
			}
			.date-text {
				flex: 0 0 0.92rem;
				margin-left: auto;
				font-family: PingFangHK;
				font-size: 0.14rem;
				color: #5e5e5e;
				text-align: right;
				white-space: nowrap;
			}
		}
	}
}
:global(.el-popper.my-tip) {
	background: #ffffff !important;
	color: #000000 !important;
	border: 0.01rem solid rgba(0, 0, 0, 0.12) !important;
	box-shadow: 0 0.04rem 0.12rem rgba(0, 0, 0, 0.12) !important;
}
:global(.el-popper.my-tip .el-popper__arrow::before) {
	background: #ffffff !important;
	border-color: rgba(0, 0, 0, 0.12) !important;
}
</style>
