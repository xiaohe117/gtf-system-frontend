<template>
	<FrameBox class="module-frame visit-overview-frame">
		<section class="module visit-overview">
			<header class="module-header">
				<div class="header-left">
					<span class="double-arrow"></span>
					<span class="module-title">{{ visitData.title }}</span>
				</div>
				<button @click="clickParent('runByEnterprise')" class="enter-btn">
					<img :src="getImage(visitData.enterImage)" alt="" />
				</button>
			</header>

			<div class="visit-summary">
				<div v-for="item in visitData.summary" :key="item.label" class="visit-stat">
					<img :src="getImage(item.icon)" alt="" />
					<div>
						<div class="metric-label">{{ item.label }}</div>
						<div class="metric-value">
							<span>{{ item.value }}</span>
							<small>{{ item.unit }}</small>
						</div>
					</div>
				</div>
			</div>

			<!-- <div class="visit-title">{{ visitData.sectionTitle }}</div> -->
			<div class="visit-body">
				<el-table
					class="visit-table"
					:data="visitData.rows"
					height="100%"
					:header-cell-style="{
						background: '#E4F1FF',
					}"
					row-key="name"
					:row-class-name="tableRowClassName"
				>
					<el-table-column
						v-for="(column, index) in visitData.columns"
						:key="column.prop"
						:prop="column.prop"
						:label="column.label"
						:align="index === 0 ? 'left' : 'center'"
					/>
				</el-table>
				<div class="visit-side">
					<div v-for="item in visitData.sideList" :key="item.label" class="side-item">
						<img :src="getImage(item.icon)" alt="" />
						<span class="side-label">{{ item.label }}</span>
						<strong class="side-value">{{ item.value }}</strong>
						<span class="side-unit">{{ item.unit }}</span>
					</div>
				</div>
			</div>
		</section>
	</FrameBox>
</template>

<script setup lang="ts">
import overallSituationData from '../data.json';
import useClickParent from '../composables/useClickParent';

const { clickParent } = useClickParent();

/** 大走访总览顶部汇总指标 */
interface VisitSummaryItem {
	/** 指标名称，如：目标企业数、任务完成率 */
	label: string;
	/** 指标数值 */
	value: string;
	/** 指标单位，没有单位时为空字符串 */
	unit: string;
	/** 指标左侧图标文件名，对应 image 目录 */
	icon: string;
}

/** 大走访转化成果表格列配置 */
interface VisitTableColumn {
	/** el-table-column 的字段名 */
	prop: string;
	/** 表头显示名称 */
	label: string;
}

/** 大走访转化成果表格行数据 */
interface VisitTableRow {
	/** 转化规模名称 */
	name: string;
	/** 数量 */
	count: string;
	/** 金额，单位为亿元 */
	amount: string;
}

/** 大走访右侧补充统计项 */
interface VisitSideItem {
	/** 统计项名称 */
	label: string;
	/** 统计项数值 */
	value: string;
	/** 单位 */
	unit: string;
	/** 统计项图标文件名，对应 image 目录 */
	icon: string;
}

/** 大走访大对接模块完整数据结构 */
interface VisitOverviewData {
	/** 模块标题 */
	title: string;
	/** 进入按钮图片文件名 */
	enterImage: string;
	/** 内容区标题 */
	sectionTitle: string;
	/** 顶部汇总指标列表 */
	summary: VisitSummaryItem[];
	/** 表格列配置 */
	columns: VisitTableColumn[];
	/** 表格行数据 */
	rows: VisitTableRow[];
	/** 右侧补充统计列表 */
	sideList: VisitSideItem[];
}

const visitData = (overallSituationData as { visitOverview: VisitOverviewData }).visitOverview;

const getImage = (name: string) => new URL(`../image/${name}`, import.meta.url).href;

const tableRowClassName = ({ rowIndex }: { rowIndex: number }) =>
	rowIndex === 1 ? 'row-white' : 'row-blue';
</script>

<style lang="less" scoped>
@import './moduleCommon.less';

.visit-overview-frame {
	min-height: 0;
	overflow: hidden;

	:deep(.outside-content) {
		min-height: 0;
		overflow: hidden;
		box-shadow: none;
	}

	:deep(.outside-content > div) {
		min-height: 0;
		overflow: hidden;
	}
}

.visit-overview {
	min-height: 0;
	overflow: hidden;
}
.visit-summary {
	display: flex;
	// grid-template-columns: repeat(3, minmax(0, 1fr));
	align-items: center;
	justify-content: space-around;
	flex: 0 0 0.64rem;
	margin: 0.04rem 0 clamp(0.08rem, 1vh, 0.12rem);
	padding: 0 clamp(0.14rem, 1.4vw, 0.28rem);
	background: url('../image/visit-summary-row.webp') center / 100% 100% no-repeat;
}

.visit-stat {
	display: flex;
	align-items: center;
	gap: clamp(0.06rem, 0.8vw, 0.12rem);
	min-width: 0;

	img {
		width: clamp(0.36rem, 4.4vh, 0.47rem);
		height: clamp(0.38rem, 4.6vh, 0.49rem);
		object-fit: contain;
	}
}

.visit-stat .metric-label {
	font-size: 0.15rem;
	line-height: clamp(0.14rem, 1.6vh, 0.17rem);
	font-weight: 700;
	color: #202a36;
	font-family:
		PingFangSC,
		PingFang SC;
}

.visit-stat .metric-value {
	display: flex;
	align-items: baseline;
	margin-top: 0.05rem;

	span {
		line-height: 0.24rem;
		font-family: DINAlternate, Arial, sans-serif;
		font-size: 0.24rem;
		font-weight: bold;
		color: #165dff;
	}

	small {
		margin-left: 0.07rem;
		font-family: PingFangHK, PingFangHK;
		font-weight: 400;
		font-size: 0.14rem;
		color: rgba(0, 0, 0, 0.65);
	}
}

.visit-title {
	display: flex;
	align-items: center;
	flex: 0 0 clamp(0.22rem, 2.8vh, 0.28rem);
	font-size: 0.16rem;
	line-height: clamp(0.17rem, 1.9vh, 0.2rem);
	color: #162438;
}

.visit-body {
	display: flex;
	flex: 1 1 0;
	height: 0;
	min-height: 0;
	overflow: hidden;
	gap: max(0.04rem, 2%);
}

.visit-table {
	width: 100%;
	height: 100%;
	flex: 1;
	background: transparent;

	:deep(.el-table),
	:deep(.el-table__inner-wrapper),
	:deep(.el-table__header-wrapper),
	:deep(.el-table__body-wrapper),
	:deep(.el-table__header),
	:deep(.el-table__body),
	:deep(.el-scrollbar),
	:deep(.el-scrollbar__wrap),
	:deep(.el-scrollbar__view) {
		background: transparent !important;
	}

	:deep(.el-table__inner-wrapper::before) {
		display: none;
	}

	:deep(.el-table__inner-wrapper) {
		display: flex;
		flex-direction: column;
		height: 100%;
		overflow: hidden !important;
	}

	:deep(.el-table__header-wrapper) {
		margin-bottom: 0.02rem;
		flex-shrink: 0;
		overflow: hidden !important;
	}

	:deep(.el-table__body-wrapper) {
		flex: 1;
		min-height: 0;
		overflow: hidden !important;
		scrollbar-width: none;
		-ms-overflow-style: none;

		&::-webkit-scrollbar {
			display: none;
			width: 0;
			height: 0;
		}
	}

	:deep(.el-scrollbar),
	:deep(.el-scrollbar__wrap),
	:deep(.el-scrollbar__bar) {
		overflow: hidden !important;
	}

	:deep(.el-scrollbar__bar) {
		display: none !important;
	}

	:deep(.el-table__header-wrapper th.el-table__cell) {
		height: clamp(0.24rem, 3vh, 0.36rem);
		padding: 0;
		border: 0;
		font-family:
			PingFangSC,
			PingFang SC;
		font-size: 0.16rem;
		font-weight: 400;
		color: #333 !important;
	}

	:deep(.el-table__body-wrapper td.el-table__cell) {
		height: clamp(0.24rem, 3vh, 0.36rem);
		padding: 0;
		border: 0;
		font-family:
			PingFangSC,
			PingFang SC;
		font-size: 0.15rem;
		color: #333 !important;
	}

	// :deep(.el-table__body tr:hover > td.el-table__cell) {
	// 	background: #F0F3FE;
	// }

	:deep(.el-table__body tr.row-blue td.el-table__cell) {
		background: #f0f3fe;
	}

	:deep(.el-table__body tr.row-white td.el-table__cell) {
		background: #fff;
	}

	// :deep(.el-table__body tr.row-blue:hover td.el-table__cell) {
	// 	background: #eef4ff;
	// }

	// :deep(.el-table__body tr.row-white:hover td.el-table__cell) {
	// 	background: #f5f9ff;
	// }
}

.visit-side {
	display: flex;
	flex-direction: column;
	justify-content: space-between;
	align-items: stretch;
	min-height: 0;
	overflow: hidden;

	.side-item {
		flex: 1;
		display: flex;
		align-items: center;
		gap: 0.08rem;
	}

	img {
		width: 0.4rem;
		height: 0.4rem;
		object-fit: contain;
		flex-shrink: 0;
	}

	.side-label {
		flex: 1;
		min-width: 0;
		font-family:
			PingFangSC,
			PingFang SC;
		font-size: 0.16rem;
		color: #333;
		white-space: nowrap;
	}

	.side-value {
		flex-shrink: 0;
		font-family: DINAlternate, Arial, sans-serif;
		font-weight: bold;
		font-size: 0.22rem;
		color: rgba(0, 0, 0, 0.65);
	}

	.side-unit {
		flex-shrink: 0;
		font-family:
			PingFangSC,
			PingFang SC;
		font-size: 0.14rem;
		font-family: PingFangHK, PingFangHK;
		font-weight: 400;
		color: #5e5e5e;
		margin-left: 0.02rem;
	}
}
</style>
