<template>
	<FrameBox class="module-frame gi-overview-frame">
		<section class="module gi-overview">
			<header class="module-header compact-header gi-header">
				<div class="header-left">
					<span class="double-arrow"></span>
					<span class="module-title">{{ giData.title }}</span>
				</div>
				<GiTabSwitch
					:model-value="activeTabKey"
					:tabs="giData.tabs"
					:disabled="isLoading"
					class="gi-tabs"
					@update:model-value="handleTabChange"
					v-if="false"
				/>
				<div></div>
				<button @click="toGI()" class="enter-btn" type="button">
					<img :src="getImage(giData.enterImage)" alt="" />
				</button>
			</header>

			<div
				v-loading="isLoading"
				class="gi-card-grid"
				element-loading-background="rgba(255, 255, 255, 0.72)"
				element-loading-text="加载中..."
			>
				<div
					v-for="(item, index) in activeCards"
					:key="`${activeTabKey}-${index}`"
					class="gi-card"
				>
					<div class="gi-card-text" :title="item.label">{{ item.label }}</div>
					<strong :class="{ 'is-empty': !item.value }">{{ item.value || '--' }}</strong>
					<span>{{ item.unit }}</span>
					<p>
						{{ item.compareLabel }}
						<small :class="{ 'is-up': item.isUp, 'is-empty': !item.rate }">
							<i v-if="item.rate">{{ item.isUp ? '▲' : '▼' }}</i>
							{{ item.rate || '--' }}
						</small>
					</p>
				</div>
			</div>
		</section>
	</FrameBox>
</template>

<script setup lang="ts">
import router from '@/router';
import { computed, onBeforeUnmount, ref } from 'vue';
import GiTabSwitch from './GiTabSwitch.vue';
import overallSituationData from '../data.json';

interface GiTabItem {
	label: string;
	key: string;
}

interface GiCardItem {
	label: string;
	value: string;
	unit: string;
	compareLabel: string;
	rate: string;
	isUp: boolean;
}

interface GiOverviewData {
	title: string;
	enterImage: string;
	tabs: GiTabItem[];
	cards: Record<string, GiCardItem[]>;
}

const giData = (overallSituationData as { giOverview: GiOverviewData }).giOverview;
const activeTabKey = ref(giData.tabs[0]?.key ?? '');
const isLoading = ref(false);
let loadingTimer: ReturnType<typeof setTimeout> | null = null;

const activeCards = computed(() => giData.cards[activeTabKey.value] ?? []);

const getImage = (name: string) => new URL(`../image/${name}`, import.meta.url).href;

const handleTabChange = (key: string) => {
	if (key === activeTabKey.value || isLoading.value) return;
	isLoading.value = true;
	loadingTimer = setTimeout(() => {
		activeTabKey.value = key;
		isLoading.value = false;
		loadingTimer = null;
	}, 300);
};

onBeforeUnmount(() => {
	if (loadingTimer) {
		clearTimeout(loadingTimer);
	}
});

const toGI = () => {
	router.push({ path: '/efficiency/index' });
};
</script>

<style lang="less" scoped>
@import './moduleCommon.less';

.gi-overview-frame {
	min-height: 0;
	overflow: hidden;

	:deep(.outside-content) {
		min-height: 0;
		overflow: hidden;
		box-shadow: none;
	}

	:deep(.outside-content > div) {
		min-height: 0;
		overflow: hidden;
	}
}

.gi-overview {
	min-height: 0;
	overflow: hidden;
}

.gi-header {
	grid-template-columns: minmax(1.1rem, 1.36rem) minmax(0, 2.1rem) clamp(0.76rem, 4.8vw, 0.82rem);
	column-gap: 0.08rem;
}

.gi-tabs {
	position: relative;
	z-index: 2;
	align-self: center;
	justify-self: center;
	left: -18%;
}

.gi-card-grid {
	position: relative;
	display: grid;
	grid-template-columns: repeat(3, minmax(0, 1fr));
	grid-auto-rows: max-content;
	flex: 1 1 0;
	height: 0;
	min-height: 0;
	overflow-y: auto;
	overflow-x: hidden;
	padding-top: 0rem;

	:deep(.el-loading-mask) {
		border-radius: 0.06rem;
	}

	:deep(.el-loading-spinner) {
		margin-top: -0.24rem;
	}

	:deep(.el-loading-spinner .circular) {
		width: 0.26rem;
		height: 0.26rem;
	}

	:deep(.el-loading-spinner .path) {
		stroke: #1680ff;
	}

	:deep(.el-loading-text) {
		margin-top: 0.04rem;
		color: #1680ff;
		font-size: 0.12rem;
	}
}

.gi-card {
	min-width: 0;
	border-radius: 0.05rem;
	background: url('../image/scene-card-bg.png') center / 100% 100% no-repeat;
	color: #42546a;
	padding: clamp(0.1rem, 1.5vh, 0.16rem) 0.1rem clamp(0.1rem, 1.5vh, 0.16rem)
		clamp(0.18rem, 1.6vw, 0.3rem);

	.gi-card-text {
		font-family:
			PingFangSC,
			PingFang SC;
		font-size: 0.14rem;
		color: #1d2129;
		min-height: 0.36rem;
		display: -webkit-box;
		-webkit-box-orient: vertical;
		-webkit-line-clamp: 2;
		line-clamp: 2;
		overflow: hidden;
	}

	strong {
		display: inline-block;
		margin-top: 0.04rem;
		font-family: DINAlternate, Arial, sans-serif;
		font-size: 0.18rem;
		color: #0578ff;

		&.is-empty {
			color: #999;
		}
	}

	span {
		margin-left: 0.04rem;
		color: #536172;
	}

	p {
		display: flex;
		align-items: center;
		margin: 0.04rem 0 0;
		color: #6a7b90;
	}

	small {
		display: inline-flex;
		align-items: center;
		gap: 0.02rem;
		margin-left: 0.3rem;
		color: #ff5b5b;
		font-size: 0.11rem;
		font-weight: 500;

		&.is-up {
			color: #18b86c;
		}

		&.is-empty {
			color: #999;
		}
	}

	i {
		font-style: normal;
		font-size: 0.1rem;
		line-height: 1;
	}
}
</style>
