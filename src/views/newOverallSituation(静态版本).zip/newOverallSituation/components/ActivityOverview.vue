<template>
	<FrameBox class="module-frame activity-frame">
		<section class="module activity-overview">
			<header class="module-header">
				<div class="header-left">
					<span class="double-arrow"></span>
					<span class="module-title">{{ activityOverview.title }}</span>
					<span class="target-text">{{ targetData.label }}</span>
					<strong>{{ targetData.value }}</strong>
					<span>{{ targetData.unit }}</span>
					<span>，完成率：</span>
					<strong>{{ targetData.completionRate }}</strong>
				</div>
				<button @click="clickParent('activityOverview')" class="enter-btn">
					<img src="@/views/newOverallSituation/image/more.png" alt="" />
				</button>
			</header>

			<div class="activity-body">
				<div class="activity-left">
					<div class="activity-main-number">
						<div class="number-title">{{ countData.label }}</div>
						<div class="number-wrap">
							<span class="number-value">{{ countData.value }}</span>
							<span class="number-unit">{{ countData.unit }}</span>
						</div>
					</div>
					<div v-for="item in activityTypes" :key="item.name" class="activity-type">
						<img class="type-icon" :src="getImage(item.icon)" alt="" />
						<div class="type-info">
							<div class="type-name">{{ item.name }}</div>
							<div class="type-value-wrap">
								<span class="type-value">{{ item.value }}</span>
								<span class="type-unit">场</span>
							</div>
						</div>
					</div>
				</div>
				<div class="activity-right">
					<div v-for="item in activityStats" :key="item.name" class="activity-stat-row">
						<i></i>
						<div class="stat-name">{{ item.name || '-' }}</div>
						<span class="stat-value">{{ item.number1 || '-' }}</span>
						<span class="stat-unit">{{ item.unit1 }}</span>
						<span v-if="item.number2" class="stat-value">{{
							item.number2 || '-'
						}}</span>
						<span v-if="item.unit2" class="stat-unit">{{ item.unit2 }}</span>
					</div>
				</div>
			</div>
		</section>
	</FrameBox>
</template>

<script setup lang="ts">
import overallSituationData from '../data.json';
import useClickParent from '../composables/useClickParent';

const { clickParent } = useClickParent();
interface ActivityTypeItem {
	name: string;
	value: string;
	icon: string;
}

interface ActivityStatItem {
	code: string;
	name: string;
	number1: string;
	unit1: string;
	number2: string;
	unit2: string;
}

interface ActivityOverviewData {
	title: string;
	target: {
		label: string;
		value: string;
		unit: string;
		completionRate: string;
	};
	totalCount: {
		label: string;
		value: string;
		unit: string;
	};
	activityTypes: ActivityTypeItem[];
	activityStats: ActivityStatItem[];
}

const { activityOverview } = overallSituationData as { activityOverview: ActivityOverviewData };
const {
	activityTypes,
	activityStats,
	totalCount: countData,
	target: targetData,
} = activityOverview;

const getImage = (name: string) => new URL(`../image/${name}`, import.meta.url).href;
</script>

<style lang="less" scoped>
@import './moduleCommon.less';

.activity-frame {
	min-height: 0;
	overflow: hidden;

	:deep(.outside-content) {
		min-height: 0;
		overflow: hidden;
		box-shadow: none;
		padding: clamp(0.07rem, 0.9vh, 0.12rem) clamp(0.09rem, 0.9vw, 0.16rem)
			clamp(0.1rem, 1.2vh, 0.2rem) clamp(0.12rem, 1.2vw, 0.2rem);
	}

	:deep(.outside-content > div) {
		min-height: 0;
		overflow: hidden;
	}
}

.activity-overview {
	min-height: 0;
	overflow: hidden;
}

.activity-body {
	display: grid;
	grid-template-columns: 2rem 1fr;
	gap: 0.1rem;
	flex: 1 1 0;
	height: 0;
	min-height: 0;
	padding-top: 0.08rem;
}

.activity-left {
	display: flex;
	flex-direction: column;
	// justify-content: center;
	// gap: 0.08rem;
	// gap: 0.06rem;
	justify-content: space-around;
	min-height: 0;
}

.activity-main-number {
	flex-shrink: 0;
	height: clamp(0.5rem, 6vh, 0.64rem);
	.number-title {
		padding-left: 0.24rem;
		font-size: 0.15rem;
		line-height: clamp(0.15rem, 1.7vh, 0.18rem);
		color: #202a36;
		font-weight: 700;
	}
	.number-wrap {
		display: flex;
		align-items: flex-end;
		gap: 0.08rem;
		padding-left: 0.24rem;
		background:
			url('../image/section-line.png') center bottom / 100% 0.1rem no-repeat,
			linear-gradient(180deg, rgba(255, 255, 255, 0) 0%, rgba(218, 242, 255, 0.58) 100%);
		.number-value {
			font-family: DINAlternate;
			font-weight: bold;
			font-size: 0.24rem;
			color: #165dff;
		}
		.number-unit {
			font-family: PingFangHK;
			font-size: 0.14rem;
			color: #5e5e5e;
			line-height: 2;
		}
	}
}

.activity-type {
	display: flex;
	flex-shrink: 0;
	align-items: center;
	gap: 0.08rem;
	.type-icon {
		width: 0.5rem;
		height: 0.5rem;
		object-fit: contain;
	}
	.type-info {
		display: flex;
		flex-direction: column;
		// gap: 0.04rem;
		.type-name {
			font-family: PingFangSC;
			font-size: 0.15rem;
			color: #333;
		}
		.type-value-wrap {
			display: flex;
			align-items: center;
			gap: 0.08rem;
			.type-value {
				font-family: DINAlternate;
				font-weight: bold;
				font-size: 0.2rem;
				color: rgba(0, 0, 0, 0.65);
			}
			.type-unit {
				font-family: PingFangHK;
				font-size: 0.14rem;
				color: #5e5e5e;
			}
		}
	}
}

.activity-right {
	display: flex;
	flex-direction: column;
	justify-content: space-around;
	// gap: 0.08rem;
	height: 100%;
	min-height: 0;
	overflow: hidden;
	.activity-stat-row {
		flex-shrink: 0;
		display: flex;
		align-items: center;
		justify-content: space-between;
		height: 0.38rem;
		padding: 0.08rem 0.08rem 0.08rem 0.24rem;
		background: url('../image/small-table-bg.png') no-repeat center center;
		background-size: 100% 100%;

		i {
			width: 0.12rem;
			height: 0.12rem;
			border: 0.02rem solid #2091ff;
			border-radius: 50%;
		}

		.stat-name {
			flex: 1;
			font-family: PingFangSC;
			font-size: 0.15rem;
			color: #333333;
			padding-left: 0.08rem;
		}
		.stat-value {
			font-family: DINAlternate;
			font-weight: bold;
			// font-size: 0.2rem;
			font-size: 0.16rem;
			color: rgba(0, 0, 0, 0.65);
			padding: 0 0.08rem;
		}
		.stat-unit {
			font-family: PingFangHK;
			font-size: 0.14rem;
			color: #5e5e5e;
		}
	}
}
</style>
