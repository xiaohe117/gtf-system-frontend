<template>
	<FrameBox class="module-frame project-overview-frame">
		<section class="module project-overview">
			<header class="module-header project-header">
				<div class="header-left">
					<span class="double-arrow"></span>
					<span class="module-title">项目总览</span>
					<span class="target-text">项目投资总额任务：</span>
					<strong>{{ projectData.target.value }}</strong>
					<span>亿元</span>
				</div>
				<button
					@click="clickParent('recruitmentByProject')"
					class="enter-btn"
					type="button"
				>
					<img src="@/views/newOverallSituation/image/more.png" alt="" />
				</button>
			</header>

			<div
				class="project-metrics"
				:style="{ backgroundImage: `url(${getImage(projectData.summaryImage)})` }"
			>
				<div v-for="item in projectData.summary" :key="item.label" class="project-metric">
					<div class="metric-label">{{ item.label }}</div>
					<div class="metric-value" :class="{ 'is-empty': item.value === '-' }">
						<span>{{ item.value }}</span>
						<i v-if="item.trend === 'up'"></i>
						<small v-if="item.unit">{{ item.unit }}</small>
					</div>
				</div>
			</div>

			<div class="flow-table">
				<div class="flow-head">
					<div v-for="item in projectData.steps" :key="item.name" class="flow-head-cell">
						<span>{{ item.name }}</span>
					</div>
				</div>
				<div class="flow-body">
					<div v-for="row in projectData.rows" :key="row.field" class="flow-row">
						<div class="flow-label" :class="{ 'is-multiline': row.label.length > 1 }">
							<span v-for="item in row.label" :key="item">{{ item }}</span>
						</div>
						<div class="flow-values">
							<div
								v-for="item in projectData.steps"
								:key="`${item.name}-${row.field}`"
								class="flow-value"
							>
								{{ item[row.field] }}
							</div>
						</div>
					</div>
				</div>
			</div>
		</section>
	</FrameBox>
</template>

<script setup lang="ts">
import overallSituationData from '../data.json';
import useClickParent from '../composables/useClickParent';

const { clickParent } = useClickParent();

type FlowField = 'count' | 'amount';

interface ProjectSummaryItem {
	label: string;
	value: string;
	unit: string;
	trend?: 'up';
}

interface ProjectStep {
	name: string;
	count: string;
	amount: string;
}

interface ProjectFlowRow {
	label: string[];
	field: FlowField;
}

interface ProjectOverviewData {
	title: string;
	enterText: string;
	enterImage: string;
	summaryImage: string;
	tableRowImage: string;
	target: {
		label: string;
		value: string;
		unit: string;
	};
	summary: ProjectSummaryItem[];
	steps: ProjectStep[];
	rows: ProjectFlowRow[];
}

const projectData = (overallSituationData as { projectOverview: ProjectOverviewData })
	.projectOverview;

const getImage = (name: string) => new URL(`../image/${name}`, import.meta.url).href;
</script>

<style lang="less" scoped>
@import './moduleCommon.less';
.project-overview {
	--flow-label-width: clamp(0.56rem, 3.5vw, 0.64rem);
	--flow-row-gap: clamp(0.08rem, 1vh, 0.14rem);
	--flow-line-color: rgba(78, 151, 244, 0.45);

	min-height: 0;
	overflow: hidden;
	font-family:
		Microsoft YaHei,
		PingFang SC,
		sans-serif;
}

.project-overview-frame {
	min-height: 0;
	overflow: hidden;

	:deep(.outside-content) {
		min-height: 0;
		overflow: hidden;
		box-shadow: none;
	}

	:deep(.outside-content > div) {
		min-height: 0;
		overflow: hidden;
	}
}

.project-header {
	grid-template-columns: minmax(0, 1fr) clamp(0.76rem, 4.8vw, 0.82rem);
}

.project-metrics {
	display: flex;
	// grid-template-columns: 1.18rem 1.75rem minmax(0, 1fr);
	justify-content: space-around;
	align-items: center;
	flex: 0 0 0.64rem;
	margin: 0.08rem 0 0.08rem;
	// padding: 0.07rem 0.1rem 0.07rem 0.5rem;
	background-repeat: no-repeat;
	background-position: center;
	background-size: 100% 100%;
}

.project-metric {
	min-width: 0;
}

.metric-label {
	font-size: 0.15rem;
	line-height: clamp(0.15rem, 1.7vh, 0.18rem);
	font-family:
		PingFangSC,
		PingFang SC;
	color: #202a36;
	font-weight: 700;
}

.metric-value {
	display: flex;
	align-items: baseline;
	min-width: 0;
	height: clamp(0.23rem, 2.6vh, 0.28rem);
	margin-top: 0.03rem;
	color: #52606f;

	span {
		font-family: DINAlternate, Arial, sans-serif;
		font-size: 0.24rem;
		font-weight: bold;
		line-height: clamp(0.23rem, 2.6vh, 0.28rem);
		color: #165dff;
		text-shadow: none;
	}

	small {
		margin-left: 0.07rem;
		line-height: clamp(0.17rem, 1.9vh, 0.2rem);
		font-family: PingFangHK, PingFangHK;
		font-weight: 400;
		font-size: 0.14rem;
		color: rgba(0, 0, 0, 0.65);
	}

	&.is-empty span {
		font-size: 0.22rem;
	}
}

.flow-table {
	display: flex;
	flex: 1 1 0;
	flex-direction: column;
	height: 0;
	min-height: 0;
	overflow: hidden;
	font-size: 0.12rem;
	font-weight: 700;
	color: #555d69;
}

.flow-body {
	flex: 1 1 0;
	height: 0;
	min-height: 0;
	display: flex;
	flex-direction: column;
	overflow: hidden;
}

.flow-head {
	display: flex;
	flex-shrink: 0;
	height: 0.35rem;
	margin-left: var(--flow-label-width);
	overflow: hidden;
	background: #fff;
}

.flow-head-cell {
	position: relative;
	display: flex;
	align-items: center;
	justify-content: center;
	flex: 1 1 0;
	min-width: 0;
	height: 100%;
	margin-left: -0.07rem;
	padding: 0 0.03rem 0 0.1rem;
	clip-path: polygon(
		0 0,
		calc(100% - 0.08rem) 0,
		100% 50%,
		calc(100% - 0.08rem) 100%,
		0 100%,
		0.08rem 50%
	);
	background: linear-gradient(135deg, #0d86ff 0%, #8fc5ff 100%);
	color: #fff;
	font-size: 0.12rem;
	line-height: 1.05;
	text-align: center;
	text-shadow: none;

	&:first-child {
		margin-left: 0;
		padding-left: 0.04rem;
		clip-path: polygon(
			0 0,
			calc(100% - 0.08rem) 0,
			100% 50%,
			calc(100% - 0.08rem) 100%,
			0 100%
		);
		background: linear-gradient(135deg, #0074f4 0%, #0f89ff 100%);
	}

	&:nth-child(2) {
		background: linear-gradient(135deg, #158dff 0%, #34a0ff 100%);
	}

	&:nth-child(3) {
		background: linear-gradient(135deg, #2f9cff 0%, #61b1ff 100%);
	}

	&:nth-child(4) {
		background: linear-gradient(135deg, #54aaff 0%, #80bcff 100%);
	}

	&:nth-child(5) {
		background: linear-gradient(135deg, #79bbff 0%, #9acaff 100%);
	}

	&:nth-child(6) {
		background: linear-gradient(135deg, #96c8ff 0%, #abd2ff 100%);
		clip-path: polygon(0 0, 100% 0, 100% 100%, 0 100%, 0.08rem 50%);
		margin-left: -0.07rem;
	}

	span {
		display: block;
		white-space: pre-line;
	}
}

.flow-row {
	display: grid;
	grid-template-columns: var(--flow-label-width) minmax(0, 1fr);
	flex: 1;
	min-height: 0;
	margin-top: 0.04rem;
}
.flow-row:nth-child(1) {
	margin-top: 0.04rem;
}

.flow-label {
	display: flex;
	align-items: center;
	justify-content: flex-start;
	min-width: 0;
	padding-left: 0.02rem;
	font-size: 0.14rem;
	line-height: 1.08;
	color: #4f5966;
	text-align: left;
	background: linear-gradient(90deg, rgba(232, 240, 253, 0.96), rgba(242, 247, 255, 0.92));

	&.is-multiline {
		flex-direction: column;
		align-items: flex-start;
		justify-content: center;
	}
}

.flow-values {
	display: grid;
	grid-template-columns: repeat(6, minmax(0, 1fr));
	min-width: 0;
	overflow: visible;
	border-radius: 0 0.13rem 0.13rem 0;
	background: linear-gradient(90deg, rgba(232, 240, 253, 0.96), rgba(242, 247, 255, 0.92));
}

.flow-value {
	position: relative;
	display: flex;
	flex-direction: column;
	align-items: center;
	justify-content: center;
	// height: clamp(0.32rem, 4vh, 0.4rem);
	min-width: 0;
	padding: 0 0.02rem;
	font-family: DINAlternate, Arial, sans-serif;
	font-size: 0.14rem;
	color: #565e6b;
	white-space: nowrap;
}
.flow-row {
	&:first-of-type {
		.flow-value {
			&::before {
				position: absolute;
				top: calc(var(--flow-row-gap) * -1);
				bottom: 0;
				left: 0;
				height: 1.06rem;
				border: 0.01rem solid;
				border-image: linear-gradient(
						180deg,
						rgba(253, 253, 253, 0),
						rgba(39, 114, 255, 0.74),
						rgba(39, 114, 255, 1),
						rgba(253, 253, 253, 0)
					)
					1 1;
				content: '';
				pointer-events: none;
			}
		}
	}
}
</style>
