<template>
	<div class="wraper">
		<div class="dept-overview">
			<ProjectOverview />
			<ClueOverview />
			<GiOverview />

			<div class="map-container">
				<div class="map-title">
					<div class="map-month-picker">
						<el-select
							v-model="mapMonthValue"
							:clearable="false"
							:suffix-icon="mapMonthSuffixIcon"
							:teleported="false"
							class="map-month-select"
							popper-class="overview-map-month-popper"
							@visible-change="handleMapMonthVisibleChange"
						>
							<el-option
								v-for="item in mapMonthOptions"
								:key="item"
								:label="item"
								:value="item"
							/>
						</el-select>
					</div>
				</div>
				<div class="map-content">
					<WorldMap v-if="activeTab === 0" @handleMapClick="handleMapClick" />
					<ChinaMap v-if="activeTab === 1" @handleMapClick="handleMapClick" />
					<RegionCount class="region-count-panel" />
					<HotCity class="hot-city-panel" />
					<!-- <EnterpriseVisitFootprint class="enterprise-visit-panel" /> -->
				</div>
			</div>

			<VisitOverview />
			<IntelligenceOverview />
			<ActivityOverview />
			<SceneOverview />
		</div>
	</div>
</template>

<script setup lang="ts">
import { CaretBottom, CaretTop } from '@element-plus/icons-vue';
import useUserStore from '@/stores/user';
import RegionCount from '@/views/newOverallSituation/DeptOverview/RegionCount.vue';
// import EnterpriseVisitFootprint from '@/views/newOverallSituation/DeptOverview/EnterpriseVisitFootprint.vue';
import ChinaMap from '@/views/newOverallSituation/DeptOverview/ChinaMap.vue';
// import WorldMap from '@/views/newOverallSituation/components/map/WorldMap.vue';
import HotCity from '@/views/newOverallSituation/DeptOverview/HotCity.vue';
import ActivityOverview from './components/ActivityOverview.vue';
import ClueOverview from './components/ClueOverview.vue';
import GiOverview from './components/GiOverview.vue';
import IntelligenceOverview from './components/IntelligenceOverview.vue';
import ProjectOverview from './components/ProjectOverview.vue';
import SceneOverview from './components/SceneOverview.vue';
import VisitOverview from './components/VisitOverview.vue';

const store = useUserStore();
const activeTab = ref(1);
const mapMonthOptions = ['2026年1-6月'];
const mapMonthValue = ref('2026年1-6月');
const isMapMonthOpen = ref(false);
const mapMonthSuffixIcon = computed(() => (isMapMonthOpen.value ? CaretTop : CaretBottom));

const handleMapMonthVisibleChange = (visible: boolean) => {
	isMapMonthOpen.value = visible;
};

watch(
	() => store.mapMode,
	() => {
		activeTab.value = Number(store.mapMode);
	},
	{ deep: true }
);

const initStore = () => {
	store.setContinentName('');
	store.setMapMode(activeTab.value);
	store.setProvinceName('');
};

initStore();

const appBgClassName = 'new-overall-situation-app-bg';
let appBgResizeObserver: ResizeObserver | null = null;
let appBgMutationObserver: MutationObserver | null = null;
let appBgInitTimer: number | undefined;
let appBgTimer: number | undefined;

const getAppContainer = () => document.querySelector<HTMLElement>('.app-container');

const updateAppBgHeight = () => {
	const appContainer = getAppContainer();

	if (!appContainer) {
		return;
	}

	const page = document.querySelector<HTMLElement>('.dept-overview');
	const pageTop = page ? page.getBoundingClientRect().top + window.scrollY : 0;
	const pageHeight = page ? page.scrollHeight : 0;
	const bgHeight = Math.ceil(Math.max(window.innerHeight, pageTop + pageHeight));

	appContainer.style.setProperty('--new-overall-situation-bg-height', `${bgHeight}px`);
};

const scheduleAppBgHeightUpdate = () => {
	if (appBgTimer) {
		window.clearTimeout(appBgTimer);
	}

	appBgTimer = window.setTimeout(() => {
		appBgTimer = undefined;
		updateAppBgHeight();
	});
};

const enableAppBgStretch = () => {
	const appContainer = getAppContainer();
	const page = document.querySelector<HTMLElement>('.dept-overview');

	if (!appContainer) {
		return;
	}

	appContainer.classList.add(appBgClassName);
	scheduleAppBgHeightUpdate();
	window.addEventListener('resize', scheduleAppBgHeightUpdate);

	if (typeof ResizeObserver !== 'undefined' && page) {
		appBgResizeObserver = new ResizeObserver(scheduleAppBgHeightUpdate);
		appBgResizeObserver.observe(page);
	}

	if (typeof MutationObserver !== 'undefined' && page) {
		appBgMutationObserver = new MutationObserver(scheduleAppBgHeightUpdate);
		appBgMutationObserver.observe(page, {
			attributes: true,
			childList: true,
			subtree: true,
		});
	}
};

const disableAppBgStretch = () => {
	const appContainer = getAppContainer();

	if (appBgInitTimer) {
		window.clearTimeout(appBgInitTimer);
		appBgInitTimer = undefined;
	}

	if (appBgTimer) {
		window.clearTimeout(appBgTimer);
		appBgTimer = undefined;
	}

	window.removeEventListener('resize', scheduleAppBgHeightUpdate);
	appBgResizeObserver?.disconnect();
	appBgMutationObserver?.disconnect();
	appBgResizeObserver = null;
	appBgMutationObserver = null;

	if (!appContainer) {
		return;
	}

	appContainer.classList.remove(appBgClassName);
	appContainer.style.removeProperty('--new-overall-situation-bg-height');
};

onMounted(() => {
	appBgInitTimer = window.setTimeout(() => {
		appBgInitTimer = undefined;
		enableAppBgStretch();
		window.dispatchEvent(new Event('resize'));
	});
});

onBeforeUnmount(() => {
	disableAppBgStretch();
});

const handleMapClick = (name: string) => {
	if (activeTab.value === 0) {
		store.setContinentName(name);
		return;
	}

	store.setProvinceName(name);
};
</script>

<style lang="less" scoped>
.wraper {
	box-sizing: border-box;
	width: 100%;
	height: 100%;
	min-height: 0;
	overflow-x: auto;
	overflow-y: auto;
}

.dept-overview {
	box-sizing: border-box;
	display: grid;
	grid-template-columns: minmax(4.9rem, 5.4rem) minmax(5.8rem, 1fr) minmax(4.9rem, 5.4rem);
	grid-template-rows: repeat(3, minmax(0, 1fr));
	align-items: stretch;
	gap: clamp(0.08rem, 0.9vh, 0.12rem);
	width: 100%;
	min-width: 15.8rem;
	height: 100%;
	min-height: 0;
	padding: clamp(0.03rem, 0.45vh, 0.04rem) 0.06rem 0.06rem;
}

.module-frame {
	min-width: 0;
	min-height: 0;
	height: 100%;
	overflow: hidden;
}

.project-overview-frame {
	grid-column: 1;
	grid-row: 1;
}

.clue-overview-frame {
	grid-column: 1;
	grid-row: 2;
}

.gi-overview-frame {
	grid-column: 1;
	grid-row: 3;
}

.visit-overview-frame {
	grid-column: 2;
	grid-row: 3;
}

.intelligence-frame {
	grid-column: 3;
	grid-row: 1;
}

.activity-frame {
	grid-column: 3;
	grid-row: 2;
}

.scene-frame {
	grid-column: 3;
	grid-row: 3;
}

.map-container {
	position: relative;
	grid-column: 2;
	grid-row: 1 / span 2;
	min-width: 0;
	min-height: 0;
	overflow: visible;
}

.map-title {
	position: absolute;
	top: 0.04rem;
	left: 50%;
	z-index: 4;
	width: 3rem;
	height: 0.76rem;
	transform: translateX(-50%);
	background: url('./image/headerback.png') center top / 100% auto no-repeat;
	pointer-events: auto;
}

.map-month-picker {
	position: absolute;
	left: 50%;
	top: 0.39rem;
	width: 1.58rem;
	height: 0.24rem;
	transform: translateX(-50%);
}

.map-month-select {
	width: 100% !important;
	height: 0.24rem;

	:deep(.el-select__wrapper) {
		min-height: 0.24rem;
		width: 1.7rem;
		height: 0.24rem;
		padding: 0 0.18rem 0 0;
		background: transparent;
		border-radius: 0;
		box-shadow: none;
	}

	:deep(.el-select__placeholder),
	:deep(.el-select__selected-item) {
		color: #fff;
		font-family:
			Microsoft YaHei,
			PingFang SC,
			sans-serif;
		font-size: 0.2rem;
		font-weight: 700;
		line-height: 0.24rem;
		text-align: center;
		text-shadow: 0 0.02rem 0.04rem rgba(0, 81, 185, 0.9);
	}

	:deep(.el-select__selected-item) {
		justify-content: center;
	}

	:deep(.el-select__suffix) {
		right: 0;
	}

	:deep(.el-select__caret) {
		color: #fff;
		font-size: 0.18rem;
		filter: drop-shadow(0 0.01rem 0.02rem rgba(0, 81, 185, 0.8));
	}
}

:deep(.overview-map-month-popper) {
	border: 0;
	border-radius: 0;
	box-shadow: 0 0.04rem 0.14rem rgba(24, 74, 143, 0.16);

	.el-popper__arrow {
		display: none;
	}

	.el-select-dropdown {
		border-radius: 0;
	}

	.el-select-dropdown__wrap {
		max-height: 4rem;
	}

	.el-select-dropdown__list {
		padding: 0;
	}

	.el-select-dropdown__item {
		height: 0.48rem;
		padding: 0 0.2rem;
		color: #5d626b;
		font-size: 0.17rem;
		font-weight: 500;
		line-height: 0.48rem;
	}

	.el-select-dropdown__item.is-hovering {
		background: #f0f2f5;
	}

	.el-select-dropdown__item.is-selected {
		color: #0d6fff;
		font-weight: 700;
	}
}

.map-content {
	position: relative;
	width: 100%;
	height: 100%;
	min-height: 0;
}

:deep(.china-map),
:deep(.world-map) {
	width: 100%;
	height: 100%;
}

.region-count-panel {
	right: 0rem !important;
	bottom: 0rem !important;
	z-index: 3;
	overflow: hidden !important;
}

.enterprise-visit-panel {
	left: 0rem;
	bottom: 0rem !important;
	z-index: 3;
	overflow: hidden !important;
}
</style>

<style lang="less">
.app-container.new-overall-situation-app-bg {
	position: relative;
	background: url('@/assets/images/menuLayout/back.png') center / 100% 100% no-repeat !important;

	&::before {
		position: absolute;
		left: 0;
		top: 0;
		z-index: 0;
		width: 100%;
		height: var(--new-overall-situation-bg-height, 100%);
		min-height: 100%;
		content: '';
		pointer-events: none;
		background: url('@/assets/images/menuLayout/back.png') center / 100% 100% no-repeat;
	}

	> * {
		position: relative;
		z-index: 1;
	}
}
</style>
