<template>
	<div class="china-map-container">
		<div class="map-pedestal-wrapper">
			<div class="map-base-pedestal"></div>
		</div>

		<div class="china-map">
			<div id="china-map-chartSvg" style="width: 100%; height: 100%"></div>
		</div>
	</div>
</template>

<script setup lang="ts">
import { ref, onMounted, onUnmounted, watch } from 'vue';
import { debounce } from 'lodash-es';
import useUserStore from '@/stores/user';
import * as echarts from 'echarts';
import mapPointImg from '@/assets/images/map/point.png';
// eslint-disable-next-line import/no-unresolved
import chinaSVG from '@/assets/images/map/china.svg?raw';

const chartInstance = ref<echarts.ECharts | null>(null);
const store = useUserStore();

const targetDestinations = [
	{ name: '北京', coord: [545, 262], interview: 153, enterprise: 116 },
	{ name: '广东', coord: [515, 520], interview: 583, enterprise: 456 },
	{ name: '上海', coord: [609, 390], interview: 44, enterprise: 39 },
	{ name: '浙江', coord: [594, 431], interview: 9, enterprise: 8 },
	{ name: '河北', coord: [530, 295], interview: 1, enterprise: 1 },
	{ name: '江苏', coord: [585, 375], interview: 4, enterprise: 4 },
	// { name: '香港', coord: [538, 533], interview: 14, enterprise: 11 },
	{ name: '湖北', coord: [499, 402], interview: 3, enterprise: 3 },
	{ name: '四川', coord: [390, 421], interview: 3, enterprise: 3 },
	{ name: '天津', coord: [554, 281], interview: 5, enterprise: 5 },
	{ name: '云南', coord: [374, 509], interview: 8, enterprise: 8 },
	// { name: '重庆', coord: [434, 432], interview: 6, enterprise: 6 },
	{ name: '吉林', coord: [638, 201], interview: 1, enterprise: 1 },
	{ name: '海南', coord: [465, 594], interview: 3, enterprise: 3 },
	{ name: '黑龙江', coord: [644, 150], interview: 1, enterprise: 1 },
	{ name: '辽宁', coord: [621, 234], interview: 1, enterprise: 1 },
	{ name: '湖南', coord: [491, 455], interview: 1, enterprise: 1 },
	// { name: '山东', coord: [564, 322], interview: 11, enterprise: 11 },
	// { name: '福建', coord: [571, 477], interview: 5, enterprise: 5 },
	{ name: '江西', coord: [539, 460], interview: 2, enterprise: 2 },
	{ name: '安徽', coord: [557, 391], interview: 2, enterprise: 1 },
	// { name: '河南', coord: [510, 363], interview: 1, enterprise: 1 },
	// { name: '澳门', coord: [511, 551], interview: 1, enterprise: 1 },
	// { name: '新疆', coord: [184, 216], interview: 1, enterprise: 1 },
	{ name: '陕西', coord: [452, 361], interview: 2, enterprise: 2 },
	// { name: '西藏', coord: [221, 389], interview: 1, enterprise: 1 },
	// { name: '内蒙古', coord: [485, 246], interview: 2, enterprise: 2 },
	// { name: '山西', coord: [496, 305], interview: 1, enterprise: 1 },
];

const hotCityData = [
	{ name: '北京', coord: [545, 262], interview: 153, enterprise: 116 },
	{ name: '上海', coord: [609, 390], interview: 44, enterprise: 39 },
	{ name: '广州', coord: [515, 520], interview: 563, enterprise: 443 },
	{ name: '深圳', coord: [520, 530], interview: 10, enterprise: 9 },
	{ name: '杭州', coord: [594, 431], interview: 7, enterprise: 6 },
];

const getLinesData = () =>
	targetDestinations.map((item) => ({
		coords: [[515, 520], item.coord],
		lineStyle: {
			curveness: 0.2,
			color: new echarts.graphic.LinearGradient(0, 0, 0, 1, [
				{ offset: 0, color: 'rgba(255, 90, 60, 0.2)' },
				{ offset: 0.5, color: 'rgba(255, 172, 78, 0.5)' },
				{ offset: 1, color: 'rgba(255, 172, 78, 0.7)' },
			]),
		},
	}));

const getBaseOption = () => {
	const layoutCenter = ['49%', '43%'];
	const layoutSize = '115%';

	return {
		tooltip: {
			trigger: 'item',
			triggerOn: 'mousemove',
			enterable: true,
			appendToBody: true,
			backgroundColor: 'transparent',
			borderWidth: 0,
			padding: 0,
			extraCssText: 'box-shadow: none; z-index: 999; pointer-events: auto;',
			position(point: any) {
				return [point[0] - 60, point[1] - 90];
			},
			formatter(params: any) {
				if (params.seriesName === '城市站点' || params.seriesName === '热门城市') {
					return `
            <div class="echarts-custom-popup">
              <div class="popup-title">${params.name}</div>
              <div class="popup-info"><span></span><span>累计对接企业：</span><span>${params.data.enterprise}</span><span>家</span></div>
              <div class="popup-info"><span></span><span>累计走访次数：</span><span>${params.data.interview}</span><span>次</span></div>
            </div>
          `;
				}
				return null;
			},
		},
		geo: [
			{
				map: 'china-custom-svg',
				roam: false,
				layoutCenter: ['49.2%', '43.4%'],
				layoutSize,
				zlevel: 1,
				itemStyle: {
					areaColor: 'rgba(15, 53, 122, 0.6)',
					borderColor: 'rgba(30, 75, 150, 0.5)',
					borderWidth: 1,
				},
			},
			{
				map: 'china-custom-svg',
				roam: false,
				layoutCenter,
				layoutSize,
				zlevel: 2,
				label: { show: false },
				itemStyle: {
					areaColor: 'transparent',
					borderColor: 'transparent',
					borderWidth: 0,
				},
				emphasis: {
					scale: false,
					label: { show: false },
					itemStyle: {
						areaColor: 'rgba(88, 167, 245, 0.15)',
					},
				},
			},
		],
		series: [
			{
				name: '城市站点',
				type: 'effectScatter',
				coordinateSystem: 'geo',
				geoIndex: 1,
				zlevel: 4,
				label: { show: false },
				symbol: `image://${mapPointImg}`,
				symbolSize: [30, 30],
				itemStyle: {
					color: 'transparent',
					shadowBlur: 0,
				},
				data: targetDestinations.map((item) => ({
					name: item.name,
					value: [...item.coord, 100],
					enterprise: item.enterprise,
					interview: item.interview,
				})),
			},
			{
				name: '发光飞线',
				type: 'lines',
				coordinateSystem: 'geo',
				geoIndex: 1,
				zlevel: 5,
				effect: {
					show: true,
					period: 3.2,
					trailLength: 0.3,
					symbol: 'arrow',
					symbolSize: 4,
					color: '#ffbe4e',
				},
				lineStyle: { width: 1, opacity: 0.8, curveness: 0.2 },
				data: getLinesData(),
			},
			{
				name: '热门城市',
				type: 'scatter',
				coordinateSystem: 'geo',
				geoIndex: 1,
				zlevel: 6,
				symbol: 'circle',
				symbolSize: 1,
				itemStyle: {
					color: 'transparent',
					opacity: 0,
				},
				data: hotCityData.map((item) => ({
					name: item.name,
					value: [...item.coord, 100],
					enterprise: item.enterprise,
					interview: item.interview,
				})),
			},
		],
	};
};

const initChart = () => {
	const chartDom = document.getElementById('china-map-chartSvg')!;
	chartInstance.value = echarts.init(chartDom);
	echarts.registerMap('china-custom-svg', { svg: chinaSVG });
	chartInstance.value.setOption(getBaseOption());
};

const handleResize = debounce(() => {
	chartInstance.value?.resize();
}, 100);

let resizeObserver: any = null;

onMounted(() => {
	initChart();
	resizeObserver = new ResizeObserver(() => handleResize());
	resizeObserver.observe(document.getElementById('china-map-chartSvg')!);
});

watch(
	() => store.hoverHotCity,
	(cityName) => {
		if (!chartInstance.value) return;

		if (cityName) {
			const cityIndex = hotCityData.findIndex((item) => item.name === cityName);
			if (cityIndex !== -1) {
				chartInstance.value.dispatchAction({
					type: 'showTip',
					seriesIndex: 2, // 热门城市系列的索引
					dataIndex: cityIndex,
				});
			}
		} else {
			chartInstance.value.dispatchAction({
				type: 'hideTip',
			});
		}
	}
);

onUnmounted(() => {
	chartInstance.value?.dispose();
	resizeObserver?.disconnect();
});
</script>

<style lang="less">
.echarts-custom-popup {
	position: relative;
	min-width: 1.69rem;
	height: 0.84rem;
	padding: 0.06rem 0.08rem;
	background: url('@/assets/images/map/popup-bg.png') no-repeat center center;
	background-size: 100% 100%;
	border-radius: 0.08rem;
	pointer-events: auto;

	.popup-title {
		font-size: 0.18rem;
		font-weight: bold;
		color: #ffd543;
		margin-bottom: 0.02rem;
		text-shadow: 0 0 5px rgba(0, 0, 0, 0.5);
	}

	.popup-info {
		font-size: 0.14rem;
		color: #e0f0ff;
		line-height: 1.4;
		span:nth-child(1) {
			width: 4px;
			height: 4px;
			background: #ff7a0d;
			display: inline-block;
			border-radius: 50%;
		}
		span:nth-child(2) {
			font-size: 0.12rem;
			margin-left: 0.04rem;
			font-weight: 500;
			display: inline-block;
		}
		span:nth-child(3) {
			font-weight: bold;
			font-size: 0.14rem;
			color: #ffd543;
			display: inline-block;
			margin-left: 0.4rem;
		}
		span:nth-child(4) {
			font-weight: 600;
			font-size: 0.08rem;
			color: #ffffff;
			display: inline-block;
		}
	}
}
</style>

<style lang="less" scoped>
.china-map-container {
	position: relative;
	width: 100%;
	height: 100%;
	overflow: hidden;
}

.map-base-pedestal {
	position: absolute;
	bottom: -60%;
	left: 50%;
	transform: translateX(-50%) rotateX(62deg);
	width: 12.9rem;
	height: 12.88rem;
	background: url(/src/assets/images/map/map-dz.png) no-repeat center center;
	background-size: 100% 100%;
	opacity: 1;
	pointer-events: none;
	z-index: 1;
}

.china-map {
	position: absolute;
	top: 0;
	left: 0;
	width: 100%;
	height: 100%;
	z-index: 2;
}
</style>
